Here is the URL to my CloudFront application of my static website

http://dps8ncoxr6dhm.cloudfront.net/index.html